from numpy import array
from inversePowerMethod import *
import pyexcel as pe
import pyexcel.ext.xls

s = 0
M = pe.get_array(file_name='test2-1.xlsx')
lam, x = inversePower(M,s,tol=1.0e-6)
print "EigenValue =" , lam
print "\nEigenVector:\n" , x
exactValue = 0.0130118738164859
print "Reporting Error: " , lam - exactValue
