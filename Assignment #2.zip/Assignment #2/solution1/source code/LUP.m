
function [L, U, P] = LUP(A)
%This function is for LU Factorization with Partial Pivoting.
%According to PDF page 66.
%--------------------------------------------------------------
[m,n] = size(A);
if m~=n
    error('The Matrix Is Not Square.'); %Determine if A is square:
end

U = A;
L = eye(m);
P = eye(m);
for k = 1:m-1
    [me, mi] = max(abs(U(k:m,k)));
    mi = mi+k-1;
    if me ~= U(k,k)
        temp = U(k,k:m);
        U(k,k:m) = U(mi,k:m);
        U(mi,k:m) = temp;
        if k >= 2
            temp = L(k,1:k-1);
            L(k,1:k-1) = L(mi,1:k-1);
            L(mi,1:k-1) = temp;
        end
        temp = P(k,:);
        P(k,:) = P(mi,:);
        P(mi,:) = temp;
    end
    for j = k+1:m
        L(j,k) = U(j,k)/U(k,k);
        U(j,k:m) = U(j,k:m)-L(j,k)*U(k,k:m);
    end
end

end