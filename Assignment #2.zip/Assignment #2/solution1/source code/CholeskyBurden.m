function C = CholeskyBurden(A)
%This function applies the Cholesky algorithm on the matrix A.
%According to Burden page 418.
%--------------------------------------------------------------

[m m] = size(A);
C = zeros(m);

C(1,1) = sqrt(A(1,1));
for j = 2:m
    C(j,1) = A(j,1)/C(1,1);
end
for i = 2:m
    C(i,i) = sqrt(A(i,i)- sum(C(i,1:i-1).^2));
    for j = i+1:m
        C(j,i) = (A(j,i)- sum(C(j,1:i-1).*C(i,1:i-1)))/C(i,i);
    end
end
C(m,m) = sqrt(A(m,m)- sum((C(m,1:m-1)).^2));
end