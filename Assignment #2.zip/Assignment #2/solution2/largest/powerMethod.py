# In the name of Allah

import numpy as np

def power_method(mat, start, maxit):

    result = start
    for i in xrange(maxit):
        result = mat*result
        result = result/np.linalg.norm(result)
    return result

def check(mat, otp):

    prd = mat*otp
    eigval = prd[0]/otp[0]
    print 'computed eigenvalue :' , eigval
    [eigs, vecs] = np.linalg.eig(mat)
    abseigs = list(abs(eigs))
    ind = abseigs.index(max(abseigs))
    print ' largest eigenvalue :', eigs[ind]
    exactValue = 128.281408780657
    print 'Reporting error: ' , (eigs[ind]-exactValue)

def main():

    print 'Running the power method...'
    dim = 20
    nbit = 50
    import pyexcel as pe     # pip install pyexcel
    import pyexcel.ext.xls   # pip install pyexcel-xls
    rnd = pe.get_array(file_name='test2-1.xlsx') # done
    rndmat = np.matrix(rnd)
    rndvec = np.matrix(rnd)
    eigmax = power_method(rndmat, rndvec, nbit)
    check(rndmat, eigmax)

main()
